#include <iostream>
using namespace std;

int main()
{
	int x = 0;
	int y = 0;

	cin >> x;
	cin >> y;
	

	cout << x + y <<endl;
}