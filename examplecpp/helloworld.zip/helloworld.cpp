#include<iostream> 
 
using namespace std;
 

int main()
{
    // prints heelo world
    cout << "Hello World";
     
    return 0;
}
