#include <iostream>
using namespace std;

int main()
{
	int x = 2;
	int y = 3;

	//cin >> x;
	//cin >> y;
	

	cout << x + y << endl;

	return 0;
}