#include <iostream>
using namespace std;

int main()
{
	int x = 2;
	int y = 2;
	

	cout << x + y <<endl;
}