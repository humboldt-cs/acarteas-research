#include <iostream>
using namespace std;

int main()
{
	string sentence = "Hello,World"
	cout << sentence <<endl;
}